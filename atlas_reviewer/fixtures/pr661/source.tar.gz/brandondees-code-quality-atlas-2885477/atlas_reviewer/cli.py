# SPDX-License-Identifier: MIT
"""Operator entry point: `python -m atlas_reviewer {review,sweep,eval,probe-runner}`.

`review --dry-run` needs no credentials and no network: GitHub is a fixture
directory, the runner is the in-memory fake, the provider is offline.
Live mode reads credentials from the environment variables named below and
hands each one only to the adapter that needs it. Live model inference is
off unless `--provider openrouter --allow-live-inference` are both given.

Every live command records lifecycle telemetry (`atlas_reviewer.telemetry`)
to a JSONL file: `--events PATH`, or by default
`<state dir>/telemetry/<command>-<UTC time to the microsecond>-<random>.jsonl`,
named only once the review lock is held. A dry run writes one only when
`--events` is given. Event text, the probe report and stderr pass through
a redactor holding every credential value from the environment and every
installation token minted during the run.
"""

from __future__ import annotations

import argparse
import fcntl
import io
import json
import math
import os
import re
import secrets
import sys
import time
from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import AbstractContextManager, ExitStack, contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO

from atlas_reviewer.budget import CallLimits
from atlas_reviewer.clock import SystemClock
from atlas_reviewer.controller import (
    DEFAULT_DIFF_CHARS_PER_CALL,
    MAX_MODEL_CALLS,
    MAX_TARBALL_BYTES,
    Deps,
    ReviewConfig,
    run_review,
)
from atlas_reviewer.domain import (
    CleanupStatus,
    InvalidEventError,
    PrEvent,
    RunnerReport,
    RunnerStatus,
    SourceKey,
    SourceKind,
)
from atlas_reviewer.draft import telemetry_section
from atlas_reviewer.eval_harness import EvalFormatError, load_directory
from atlas_reviewer.fakes import FakeSprites, MemoryLedger
from atlas_reviewer.github_api import GitHubClient
from atlas_reviewer.github_auth import READ_PERMISSIONS, AppInstallationTokens
from atlas_reviewer.github_fixture import FixtureGitHub
from atlas_reviewer.harness import SkillBundleHarness, load_bundle
from atlas_reviewer.http import UrllibStreamingTransport, UrllibTransport
from atlas_reviewer.instrumented import InstrumentedGitHub
from atlas_reviewer.interpreter import TrustedPython
from atlas_reviewer.ledger import (
    FileLedger,
    ReviewInProgressError,
    make_private_dirs,
    single_review_lock,
)
from atlas_reviewer.openrouter import OpenRouterProvider, model_route
from atlas_reviewer.picker import Depth
from atlas_reviewer.ports import BoundaryError, Clock, ModelProvider, SpritesApi
from atlas_reviewer.providers import OfflineProvider
from atlas_reviewer.redact import Redactor
from atlas_reviewer.runner import (
    DEFAULT_TOOLS,
    FIRST_FRAME_BUDGET_S,
    TRIVIAL_TOOL,
    Diagnostic,
    RunnerJob,
    Swept,
    ToolAbsent,
    ToolRan,
    ToolResult,
    event_runner_name,
    probe_runner,
    run_disposable,
    runner_name,
    sweep,
)
from atlas_reviewer.sprites_api import RUNNER_PREFIX, SpritesClient
from atlas_reviewer.stops import raise_if_stopped
from atlas_reviewer.telemetry import JsonlSink, Telemetry
from atlas_reviewer.tracing import (
    header_values,
    shared_trace,
    shutdown_shared,
    validate_export,
)
from atlas_reviewer.verdict import ReviewEvent, Verdict

ENV_APP_ID = "ATLAS_GITHUB_APP_ID"
ENV_APP_KEY = "ATLAS_GITHUB_APP_PRIVATE_KEY"
ENV_INSTALLATION_ID = "ATLAS_GITHUB_INSTALLATION_ID"
# A read-only installation token minted by the webhook parent. When it is
# set, the review does not read the App private key.
ENV_INSTALLATION_TOKEN = "ATLAS_GITHUB_INSTALLATION_TOKEN"
ENV_SPRITES_TOKEN = "ATLAS_SPRITES_TOKEN"
ENV_OPENROUTER_KEY = "ATLAS_OPENROUTER_API_KEY"
ENV_STATE_DIR = "ATLAS_REVIEWER_STATE_DIR"
DEFAULT_STATE_DIR = Path(".atlas-reviewer-state")
PROVIDER_CHOICES = ("offline", "openrouter")
SECRET_ENV = (ENV_APP_KEY, ENV_SPRITES_TOKEN, ENV_OPENROUTER_KEY)

EXIT_OK, EXIT_USAGE, EXIT_BOUNDARY, EXIT_INCOMPLETE = 0, 2, 3, 4
EXIT_CHANGES_REQUESTED = 5


class UsageError(Exception):
    pass


def load_event(path: Path) -> PrEvent:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UsageError(f"cannot read event file {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise UsageError("event file must hold a JSON object")
    try:
        return PrEvent(
            repo=data.get("repo", ""),
            pr_number=data.get("pr_number", 0),
            head_sha=data.get("head_sha", ""),
        )
    except InvalidEventError as exc:
        raise UsageError(f"invalid event: {exc}") from exc


def parse_expected(values: Sequence[str]) -> tuple[SourceKey, ...]:
    kinds = {k.value: k for k in SourceKind if k is not SourceKind.LISTING}
    keys = []
    for value in values:
        kind, sep, name = value.partition(":")
        if not sep or kind not in kinds or not name:
            raise UsageError(
                f"--expect must be KIND:NAME with KIND in {sorted(kinds)}, got {value!r}"
            )
        keys.append(SourceKey(kinds[kind], name))
    return tuple(keys)


def _require_env(env: Mapping[str, str], name: str) -> str:
    value = env.get(name, "")
    if not value:
        raise UsageError(f"this command needs the {name} environment variable")
    return value


def _pem(raw: str) -> str:
    return raw.replace("\\n", "\n") if "\n" not in raw else raw


def _installation_id(env: Mapping[str, str]) -> int:
    raw = _require_env(env, ENV_INSTALLATION_ID)
    if not (raw.isascii() and raw.isdigit() and int(raw) > 0):
        raise UsageError(f"{ENV_INSTALLATION_ID} must be a positive integer")
    return int(raw)


def _state_dir(args: argparse.Namespace, env: Mapping[str, str]) -> Path:
    return Path(args.state_dir or env.get(ENV_STATE_DIR) or DEFAULT_STATE_DIR)


@dataclass(frozen=True)
class _Wiring:
    deps: Deps
    mode: str


def _select_provider(
    args: argparse.Namespace,
    env: Mapping[str, str],
    openrouter: Callable[[str, CallLimits], OpenRouterProvider],
    telemetry: Telemetry,
) -> ModelProvider:
    if args.provider == "offline":
        return OfflineProvider()
    if args.dry_run:
        raise UsageError("--dry-run is offline-only; drop --provider openrouter")
    if not args.allow_live_inference:
        raise UsageError(
            "live inference is off: pass --allow-live-inference with --provider openrouter"
        )
    provider = openrouter(
        _require_env(env, ENV_OPENROUTER_KEY),
        CallLimits(max_calls=args.max_model_calls),
    )
    if isinstance(provider, OpenRouterProvider):
        provider.configure(
            model_route(
                env,
                model=args.model,
                providers=args.providers,
                allow_safety_retention=args.allow_safety_retention,
            )
        )
    telemetry.span("model preflight", "key status", provider.preflight)
    return provider


def _live_openrouter(key: str, limits: CallLimits) -> OpenRouterProvider:
    return OpenRouterProvider(UrllibTransport(), key, limits=limits, sleep=time.sleep)


class _Credentials:
    """Every credential value one invocation holds: the environment's, and
    each installation token minted since. `redactor` reads the minted ones
    on every call, so telemetry, the probe report and stderr written after
    a mint all lose the token."""

    def __init__(self, env: Mapping[str, str]) -> None:
        values = [env.get(name, "") for name in SECRET_ENV]
        values.append(_pem(env.get(ENV_APP_KEY, "")))
        values.append(env.get(ENV_INSTALLATION_TOKEN, ""))
        values.extend(header_values(env))
        self._sources: list[Callable[[], Sequence[str]]] = []
        self.redactor = Redactor(
            tuple(dict.fromkeys(v for v in values if v)), sources=(self._minted,)
        )

    def register(self, source: Callable[[], Sequence[str]]) -> None:
        self._sources.append(source)

    def scrub(self, text: str) -> str:
        return self.redactor(text).text

    def _minted(self) -> tuple[str, ...]:
        return tuple(s for source in self._sources for s in source())


@dataclass
class _Run:
    """One invocation's state that is not a command-line option."""

    env: Mapping[str, str]
    out: TextIO
    err: TextIO
    credentials: _Credentials
    telemetry: Telemetry | None = None


def _review_lock(
    args: argparse.Namespace, env: Mapping[str, str]
) -> AbstractContextManager[None]:
    state_dir = _state_dir(args, env)
    try:
        make_private_dirs(state_dir)
    except OSError as exc:
        raise UsageError(f"--state-dir {state_dir}: cannot be created ({exc})") from exc
    return single_review_lock(state_dir / "review.lock")


def _telemetry(
    args: argparse.Namespace,
    run: _Run,
    command: str,
    claims: ExitStack,
    *,
    default_file: bool,
) -> Telemetry:
    """Call with the review lock held: a contender that loses the lock must
    not have created, let alone written, a telemetry file. An explicit
    `--events` file is claimed before it is opened, for the same reason.
    The sink's descriptor and the claim are released when `claims` closes."""
    clock = SystemClock()
    stamp = f"{clock.now():%Y%m%dT%H%M%S.%fZ}-{secrets.token_hex(4)}"
    default = _state_dir(args, run.env) / "telemetry" / f"{command}-{stamp}.jsonl"
    path = Path(args.events) if args.events else (default if default_file else None)
    if path is None:
        return Telemetry(clock, None, scrub=run.credentials.scrub)
    if args.events:
        claims.enter_context(_claimed(path))
    try:
        sink = claims.enter_context(JsonlSink(path))
    except OSError as exc:
        raise UsageError(f"telemetry file {path}: {exc}") from exc
    return Telemetry(clock, sink, scrub=run.credentials.scrub)


@contextmanager
def _claimed(path: Path) -> Iterator[None]:
    """Hold `<path>.lock` for this run. The review lock is per state
    directory, so two runs with different state directories could still
    interleave their events in one explicit `--events` file. Locking a
    sibling leaves a refused run with no telemetry file; the lock file
    stays, since unlinking one another run may be opening would race."""
    lock = path.with_name(f"{path.name}.lock")
    try:
        make_private_dirs(path.parent)
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT, 0o600)
    except OSError as exc:
        raise UsageError(f"telemetry file {path}: {exc}") from exc
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise UsageError(f"telemetry file {path} is in use by another run") from exc
        yield
    finally:
        os.close(fd)


def _telemetry_line(run: _Run, telemetry: Telemetry) -> str:
    """Scrubbed like any other stderr text: an `--events` path is free text
    that could hold a credential value."""
    sink = telemetry.sink
    path = str(sink.path) if isinstance(sink, JsonlSink) else "(not written)"
    return (
        f"telemetry: {len(telemetry.events)} event(s), {run.credentials.scrub(path)}\n"
    )


def _dry_run_wiring(
    args: argparse.Namespace,
    event_path: Path,
    provider: ModelProvider,
    telemetry: Telemetry,
) -> _Wiring:
    fixtures = Path(args.fixtures) if args.fixtures else event_path.parent
    if not fixtures.is_dir():
        raise UsageError(f"fixture directory {fixtures} does not exist")
    redactor = Redactor()
    clock = SystemClock()
    deps = Deps(
        github=FixtureGitHub(fixtures),
        sprites=_scripted_runner(fixtures / "runner-script.json"),
        ledger=MemoryLedger(),
        harness=SkillBundleHarness(provider, load_bundle(), redactor),
        clock=clock,
        redactor=redactor,
        runner_name=lambda: runner_name(clock),
        telemetry=telemetry,
    )
    return _Wiring(
        deps, f"dry run (fixtures: {fixtures}; fake runner; provider {provider.name})"
    )


def _scripted_runner(path: Path) -> FakeSprites:
    if not path.is_file():
        return FakeSprites.from_script({})
    try:
        script = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise UsageError(f"cannot read runner script {path}: {exc}") from exc
    if not isinstance(script, dict):
        raise UsageError(f"runner script {path} must hold a JSON object")
    try:
        return FakeSprites.from_script(script)
    except (KeyError, TypeError, ValueError) as exc:
        raise UsageError(f"invalid runner script {path}: {exc!r}") from exc


class _FixedToken:
    """A token the parent already minted. It cannot mint another.

    GitHub installation tokens last one hour. The service stops the child
    at 1,200 seconds, which is inside that hour, so this token is not
    refreshed."""

    def __init__(self, token: str) -> None:
        self._token = token

    def token(self) -> str:
        return self._token

    def secrets(self) -> tuple[str, ...]:
        return (self._token,)


def _app_tokens(
    env: Mapping[str, str],
    event: PrEvent,
    include_issues: bool,
    transport: UrllibTransport,
) -> AppInstallationTokens:
    return AppInstallationTokens(
        transport,
        SystemClock(),
        app_id=_require_env(env, ENV_APP_ID),
        private_key=_pem(_require_env(env, ENV_APP_KEY)),
        installation_id=_installation_id(env),
        permissions=_permissions(include_issues),
        repositories=(event.repo.split("/", 1)[1],),
    )


def _live_wiring(
    args: argparse.Namespace,
    env: Mapping[str, str],
    event: PrEvent,
    provider: ModelProvider,
    telemetry: Telemetry,
    runner: str,
    credentials: _Credentials,
) -> _Wiring:
    _require_env(env, ENV_SPRITES_TOKEN)
    clock = SystemClock()
    transport = UrllibTransport()
    fixed = env.get(ENV_INSTALLATION_TOKEN, "")
    tokens: _FixedToken | AppInstallationTokens
    if fixed:
        tokens = _FixedToken(fixed)
    else:
        _require_env(env, ENV_APP_KEY)
        tokens = _app_tokens(env, event, args.include_issues, transport)
    credentials.register(tokens.secrets)
    redactor = credentials.redactor
    sprites = args.sprites_factory(env)
    _require_runner_absent(sprites, runner)
    deps = Deps(
        github=GitHubClient(transport, tokens),
        sprites=sprites,
        ledger=FileLedger(_state_dir(args, env) / "runners.ledger"),
        harness=SkillBundleHarness(provider, load_bundle(), redactor),
        clock=clock,
        redactor=redactor,
        runner_name=lambda: runner,
        telemetry=telemetry,
    )
    return _Wiring(deps, f"live (GitHub App + Sprites; provider {provider.name})")


def _require_runner_absent(api: SpritesApi, name: str) -> None:
    """The name comes from the event, so a Sprite that already holds it was
    left by an earlier review of this commit or belongs to one still
    running. Neither is a fresh runner."""
    if api.exists(name):
        raise BoundaryError(
            f"a Sprite named {name} already exists. If no review of this commit "
            f"is running, delete it with `sweep --runner {name} --force-live`, "
            "then review again"
        )


def _permissions(include_issues: bool) -> dict[str, str]:
    base = dict(READ_PERMISSIONS)
    return {**base, "issues": "read"} if include_issues else base


def _review_config(args: argparse.Namespace, mode: str) -> ReviewConfig:
    try:
        return ReviewConfig(
            expected=parse_expected(args.expect),
            include_issues=args.include_issues,
            deadline_s=args.deadline_seconds,
            mode=mode,
            model_calls=args.max_model_calls,
            diff_chars_per_call=args.diff_chars_per_call,
            first_frame_s=args.first_frame_seconds,
            depth=Depth(args.depth),
        )
    except ValueError as exc:
        raise UsageError(str(exc)) from exc


def _cmd_review(args: argparse.Namespace, run: _Run) -> int:
    env, out, err = run.env, run.out, run.err
    # ATLAS_* limit variables are not read here, and this command does not
    # accept the agentic limit flags. D25's one-shot ceilings stay, and a
    # value such as ATLAS_MAX_CALLS=10 must not refuse this command. The
    # lens entry point is what applies the variables.
    event_path = Path(args.event)
    event = load_event(event_path)
    _review_config(args, "check")
    _check_out_path(args.out)
    with _review_lock(args, env), ExitStack() as claims:
        telemetry = _telemetry(
            args, run, "review", claims, default_file=not args.dry_run
        )
        run.telemetry = telemetry
        provider = _select_provider(args, env, args.openrouter_factory, telemetry)
        if args.dry_run:
            wiring = _dry_run_wiring(args, event_path, provider, telemetry)
        else:
            runner = event_runner_name(event)
            err.write(f"atlas_reviewer: runner Sprite for this review: {runner}\n")
            wiring = _live_wiring(
                args, env, event, provider, telemetry, runner, run.credentials
            )
        outcome = run_review(event, wiring.deps, _review_config(args, wiring.mode))
    written = _emit(outcome.draft, args.out, out, err)
    verdict = outcome.verdict
    # Stdout carries the draft unless it went to a file; the summary must
    # not be appended to a draft someone pipes on.
    (out if written else err).write(
        f"{_telemetry_line(run, telemetry)}"
        f"review event: {verdict.event.value}; coverage_complete="
        f"{str(verdict.coverage_complete).lower()}; unreviewed_files="
        f"{len(verdict.coverage.unreviewed)}\n"
    )
    return review_exit(verdict)


def review_exit(verdict: Verdict) -> int:
    """`review`'s exit code, enough to gate a pipeline on: 4 when file
    coverage is incomplete (D36), whatever the model proposed; with
    complete coverage, 5 when the review requests changes, else 0."""
    if not verdict.coverage_complete:
        return EXIT_INCOMPLETE
    if verdict.event is ReviewEvent.REQUEST_CHANGES:
        return EXIT_CHANGES_REQUESTED
    return EXIT_OK


def _check_out_path(out_path: str | None) -> None:
    """Refuse an unwritable `--out` before the review spends anything."""
    if out_path is None:
        return
    path = Path(out_path)
    parent = path.parent
    if path.is_symlink() and not path.exists():
        raise UsageError(f"--out {out_path}: a symlink to a missing target")
    if path.is_dir() or not parent.is_dir():
        raise UsageError(f"--out {out_path}: not a file in an existing directory")
    target = path if path.exists() else parent
    if not os.access(target, os.W_OK):
        raise UsageError(f"--out {out_path}: not writable")


def _emit(draft: str, out_path: str | None, out: TextIO, err: TextIO) -> bool:
    """True if the draft went to `out_path`. A failed write still delivers
    the draft on stdout and leaves the exit code to the review's result:
    the review finished, so a retry would only repeat it."""
    if out_path is None:
        out.write(draft)
        return False
    try:
        fd = os.open(out_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(draft)
    except OSError as exc:
        out.write(draft)
        err.write(
            f"atlas_reviewer: could not write --out {out_path} ({exc}); "
            "the draft went to stdout\n"
        )
        return False
    out.write(f"review draft written to {out_path}\n")
    return True


def _live_sprites(env: Mapping[str, str]) -> SpritesApi:
    return SpritesClient(
        UrllibStreamingTransport(), _require_env(env, ENV_SPRITES_TOKEN)
    )


def _cmd_sweep(args: argparse.Namespace, run: _Run) -> int:
    env, out = run.env, run.out
    named = _named_runners(args)
    api = args.sprites_factory(env)
    # The ledger lists a live review's runner too; sweeping during a review
    # would destroy it mid-run, so sweep waits its turn like review does.
    with _review_lock(args, env):
        ledger = FileLedger(_state_dir(args, env) / "runners.ledger")
        _require_force_live(args, ledger.pending())
        for name in named:
            ledger.record(name)
        results = sweep(api, ledger)
    out.writelines(f"{name}: {_swept_line(r)}\n" for name, r in results.items())
    out.write(f"{len(results)} runner(s) in the ledger\n")
    verified = all(
        r.cleanup is CleanupStatus.DESTROYED_VERIFIED for r in results.values()
    )
    return EXIT_OK if verified else EXIT_BOUNDARY


def _swept_line(result: Swept) -> str:
    if result.cleanup is CleanupStatus.DESTROYED_VERIFIED and not result.deleted:
        return "already absent, nothing deleted (verified absent)"
    return result.cleanup.value


_RUNNER_NAME = re.compile(re.escape(RUNNER_PREFIX) + r"[a-z0-9-]+")


def _named_runners(args: argparse.Namespace) -> list[str]:
    """Runners to add to this machine's ledger before sweeping it: a review
    on another machine recorded them in a ledger this one cannot read."""
    names = list(args.runner)
    if args.event:
        names.append(event_runner_name(load_event(Path(args.event))))
    for name in names:
        if not _RUNNER_NAME.fullmatch(name):
            raise UsageError(
                f"--runner must be a {RUNNER_PREFIX}* name of lowercase letters, "
                f"digits and hyphens, got {name!r}"
            )
    if names and not args.force_live:
        raise UsageError(
            "no lock covers a runner recorded on another machine, so a review "
            "still running there would lose its runner mid-run. Check that no "
            "review of that commit is running, then add --force-live"
        )
    return names


def _require_force_live(args: argparse.Namespace, pending: Sequence[str]) -> None:
    """A ledger entry does not show this machine's create made the Sprite:
    a create of unknown outcome keeps its name, and a review of the same
    commit on another machine may have created that name since."""
    if pending and not args.force_live:
        raise UsageError(
            f"the ledger lists {len(pending)} runner(s). A name whose create "
            "was never confirmed may now be the runner of a review of that "
            "commit on another machine, and no lock covers that. Check that "
            "no such review is running, then add --force-live"
        )


def _cmd_probe(args: argparse.Namespace, run: _Run) -> int:
    env, out = run.env, run.out
    sequence = _PROBE_SEQUENCES[args.sequence]
    report = io.StringIO()
    with _review_lock(args, env), ExitStack() as claims:
        telemetry = _telemetry(
            args, run, f"probe-{args.sequence}", claims, default_file=True
        )
        run.telemetry = telemetry
        try:
            usable = sequence(args, run, report, telemetry)
        finally:
            out.write(run.credentials.scrub(report.getvalue()))
    out.write(f"\n{telemetry_section(telemetry.events)}\n\n")
    out.write(_telemetry_line(run, telemetry))
    if not usable:
        out.write("probe: FAILED -- the runner is not usable as probed\n")
    return EXIT_OK if usable else EXIT_BOUNDARY


def _probe_protocol(
    args: argparse.Namespace, run: _Run, out: TextIO, telemetry: Telemetry
) -> bool:
    env = run.env
    clock: Clock = SystemClock()
    outcome = probe_runner(
        args.sprites_factory(env),
        FileLedger(_state_dir(args, env) / "runners.ledger"),
        DEFAULT_TOOLS,
        name=runner_name(clock),
        deadline_s=args.deadline_seconds,
        clock=clock,
        telemetry=telemetry,
        first_frame_s=args.first_frame_seconds,
    )
    _write_report(outcome.report, out)
    out.writelines(
        f"tool {b}: {'present' if ok else 'ABSENT'}\n"
        for b, ok in outcome.available.items()
    )
    out.write(f"raw exec response sample: {outcome.framing_sample[:200]!r}\n")
    out.write(f"stdin round-trip: {outcome.stdin_check}\n")
    out.write(f"outbound connection: {outcome.egress_check}\n")
    return (
        outcome.report.status is RunnerStatus.COMPLETED
        and outcome.stdin_check.startswith("ok:")
        and not outcome.egress_check.startswith("OPEN")
    )


def _probe_review_sequence(
    args: argparse.Namespace, run: _Run, out: TextIO, telemetry: Telemetry
) -> bool:
    """The review's exact exec sequence (tool check, upload, unpack, tools)
    on a real checkout, with no model call and no evidence gathering."""
    env, credentials = run.env, run.credentials
    tarball = _probe_source(args, env, telemetry, credentials)
    if len(tarball) > MAX_TARBALL_BYTES:
        raise UsageError(f"tarball is {len(tarball)} bytes, over {MAX_TARBALL_BYTES}")
    clock: Clock = SystemClock()
    tools = DEFAULT_TOOLS if args.tools == "review" else (TRIVIAL_TOOL,)
    outcome = run_disposable(
        args.sprites_factory(env),
        FileLedger(_state_dir(args, env) / "runners.ledger"),
        RunnerJob(tarball, tools, diagnose=True),
        name=runner_name(clock),
        deadline_s=args.deadline_seconds,
        clock=clock,
        telemetry=telemetry,
        first_frame_s=args.first_frame_seconds,
    )
    _write_report(outcome.report, out)
    out.write(f"source tarball: {len(tarball)} bytes\n")
    redactor = credentials.redactor
    out.writelines(f"{_tool_report(r, redactor)}\n" for r in outcome.results)
    out.write(f"{_python_report(outcome.python)}\n")
    out.writelines(f"{_diagnostic_report(d)}\n" for d in outcome.diagnostics)
    return outcome.report.status is RunnerStatus.COMPLETED


def _python_report(python: TrustedPython | None) -> str:
    if python is None:
        return "trusted python: none resolved"
    return f"trusted python: {python.path} ({python.version})"


def _diagnostic_report(result: Diagnostic) -> str:
    return (
        f"diagnostic {result.name}: exit {result.exit_code}: {result.detail} "
        f"[expected: {result.expectation}]"
    )


def _probe_source(
    args: argparse.Namespace,
    env: Mapping[str, str],
    telemetry: Telemetry,
    credentials: _Credentials,
) -> bytes:
    if args.tarball:
        return _read_tarball(Path(args.tarball))
    if not args.event:
        raise UsageError("--sequence review needs --tarball FILE or --event FILE")
    event = load_event(Path(args.event))
    transport = UrllibTransport()
    tokens = _app_tokens(env, event, False, transport)
    credentials.register(tokens.secrets)
    github = InstrumentedGitHub(GitHubClient(transport, tokens), telemetry)
    return github.get_tarball(event.repo, event.head_sha)


def _read_tarball(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise UsageError(f"cannot read tarball {path}: {exc}") from exc


def _write_report(r: RunnerReport, out: TextIO) -> None:
    out.write(f"runner: {r.runner_name}\nstatus: {r.status.value}\n")
    out.write(f"cleanup: {r.cleanup.value}\nnote: {r.note}\n")


def _tool_report(result: ToolResult, redactor: Redactor) -> str:
    match result:
        case ToolRan(tool=tool, version=version, exit_code=code, output=output):
            shown = redactor(output).text[-300:]
            return f"tool {tool.name} ({version}): exit {code}; output: {shown!r}"
        case ToolAbsent(tool=tool, detail=detail):
            return f"tool {tool.name}: not run -- {detail}"
    raise TypeError(f"not a tool result: {result!r}")  # pragma: no cover


_PROBE_SEQUENCES: dict[
    str,
    Callable[[argparse.Namespace, _Run, TextIO, Telemetry], bool],
] = {"protocol": _probe_protocol, "review": _probe_review_sequence}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="atlas_reviewer",
        description="Manual Code Quality Atlas review (draft only).",
    )
    parser.add_argument(
        "--state-dir",
        help=f"controller-local state (default: ${ENV_STATE_DIR} or {DEFAULT_STATE_DIR})",
    )
    parser.set_defaults(
        sprites_factory=_live_sprites, openrouter_factory=_live_openrouter
    )
    sub = parser.add_subparsers(dest="command", required=True)
    rev = sub.add_parser("review", help="review one PR event and write a draft")
    rev.add_argument(
        "--event", required=True, help="JSON file with repo, pr_number, head_sha"
    )
    rev.add_argument(
        "--dry-run",
        action="store_true",
        help="fixtures + fake runner + offline provider; no credentials",
    )
    rev.add_argument(
        "--fixtures",
        help="fixture directory for --dry-run (default: the event file's directory)",
    )
    rev.add_argument("--out", help="write the draft here instead of stdout")
    rev.add_argument(
        "--expect",
        action="append",
        default=[],
        metavar="KIND:NAME",
        help="evidence that must exist",
    )
    rev.add_argument(
        "--include-issues",
        action="store_true",
        help="opt in to fetching issues the PR closes",
    )
    rev.add_argument(
        "--deadline-seconds",
        type=_positive_seconds,
        default=600.0,
        help="external runner deadline",
    )
    rev.add_argument(
        "--max-model-calls",
        type=int,
        default=MAX_MODEL_CALLS,
        help=(
            "model calls per review, retries included: one for the lens picker "
            "(except at triage depth, or when no picked lens could fit), the rest "
            f"for diff parts (1-{MAX_MODEL_CALLS})"
        ),
    )
    rev.add_argument(
        "--diff-chars-per-call",
        type=int,
        default=DEFAULT_DIFF_CHARS_PER_CALL,
        help=(
            "most diff characters a model call may carry; each review shrinks "
            "parts further to fit its measured prompt under the token bound"
        ),
    )
    rev.add_argument(
        "--depth",
        choices=[d.value for d in Depth],
        default=Depth.REVIEW.value,
        help="the atlas depth mode: triage runs the critical tier with no picker call",
    )
    _events_arg(rev)
    rev.add_argument(
        "--model",
        default=None,
        help=(
            "OpenRouter model id (env ATLAS_MODEL; default "
            "anthropic/claude-sonnet-5.5). A response from any other model "
            "is rejected."
        ),
    )
    rev.add_argument(
        "--providers",
        default=None,
        help=(
            "comma-separated provider slugs for provider.only (env "
            "ATLAS_PROVIDERS; default amazon-bedrock,google-vertex/europe,"
            "google-vertex/global,google-vertex/us). One slug pins that "
            "provider. A slug with no pure-ZDR endpoint for the model is "
            "refused."
        ),
    )
    rev.add_argument(
        "--allow-safety-retention",
        action="store_true",
        help=(
            "allow OpenRouter Safety Retention endpoints (env "
            "ATLAS_ALLOW_SAFETY_RETENTION=true). Off by default: a request "
            "stays on pure zero-data-retention endpoints."
        ),
    )
    rev.add_argument("--provider", choices=PROVIDER_CHOICES, default="offline")
    rev.add_argument(
        "--allow-live-inference",
        action="store_true",
        help="required with --provider openrouter; spends real money (capped)",
    )
    _first_frame_arg(rev)
    rev.set_defaults(handler=_cmd_review)
    swp = sub.add_parser(
        "sweep", help="destroy runners a crashed review left in the ledger"
    )
    swp.add_argument(
        "--runner",
        action="append",
        default=[],
        metavar="NAME",
        help="also destroy this runner, recorded in another state dir's ledger",
    )
    swp.add_argument(
        "--event",
        help="also destroy the runner a review of this event file is named",
    )
    swp.add_argument(
        "--force-live",
        action="store_true",
        help="required to delete anything: you checked no review using it runs",
    )
    swp.set_defaults(handler=_cmd_sweep)
    ev = sub.add_parser(
        "eval",
        help="score recorded reviews against reference fixtures (offline)",
    )
    ev.add_argument(
        "--fixtures",
        required=True,
        help="directory of reference rows and optional candidate pairs",
    )
    ev.add_argument(
        "--head",
        help="commit the gate must have a passing pair for",
    )
    ev.add_argument(
        "--gate",
        action="store_true",
        help="exit 1 unless every row is a passing pair, one matches --head, "
        "and one records over_context_window",
    )
    ev.set_defaults(handler=_cmd_eval)
    probe = sub.add_parser(
        "probe-runner",
        help="live Sprites check without a model: protocol, or the review's exec sequence",
    )
    probe.add_argument("--deadline-seconds", type=_positive_seconds, default=120.0)
    probe.add_argument(
        "--sequence",
        choices=tuple(_PROBE_SEQUENCES),
        default="protocol",
        help="protocol: tool check, framing, 3 MiB stdin; review: tool check, "
        "upload, unpack and tools, exactly as a review runs them",
    )
    probe.add_argument("--tarball", help="--sequence review: a local .tar.gz checkout")
    probe.add_argument(
        "--event",
        help="--sequence review: fetch the head-SHA tarball via the GitHub App",
    )
    probe.add_argument(
        "--tools",
        choices=("trivial", "review"),
        default="trivial",
        help="--sequence review: a trivial file count, or the review's default tools",
    )
    _events_arg(probe)
    _first_frame_arg(probe)
    probe.set_defaults(handler=_cmd_probe)
    return parser


def _first_frame_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--first-frame-seconds",
        type=_positive_seconds,
        default=FIRST_FRAME_BUDGET_S,
        help="fail an exec that sends no input if no output byte arrives in this time",
    )


def _positive_seconds(text: str) -> float:
    value = float(text)
    if not (math.isfinite(value) and value > 0):
        raise argparse.ArgumentTypeError("must be a positive number of seconds")
    return value


def _events_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--events", help="telemetry JSONL file (default: under <state dir>/telemetry/)"
    )


def _cmd_eval(args: argparse.Namespace, run: _Run) -> int:
    """Score recorded fixtures. No model call and no network."""
    try:
        report = load_directory(Path(args.fixtures), head=args.head)
    except EvalFormatError as exc:
        raise UsageError(str(exc)) from exc
    run.out.write(json.dumps(report, indent=2) + "\n")
    if args.gate and not report["gate_pass"]:
        return 1
    return EXIT_OK


_ERRORS: tuple[tuple[type[Exception], int], ...] = (
    (UsageError, EXIT_USAGE),
    (ReviewInProgressError, EXIT_USAGE),
    (BoundaryError, EXIT_BOUNDARY),
)


def main(
    argv: Sequence[str] | None = None,
    env: Mapping[str, str] | None = None,
    out: TextIO | None = None,
    err: TextIO | None = None,
    *,
    sprites_factory: Callable[[Mapping[str, str]], SpritesApi] | None = None,
    openrouter_factory: Callable[[str, CallLimits], OpenRouterProvider] | None = None,
) -> int:
    args = build_parser().parse_args(argv)
    if sprites_factory is not None:
        args.sprites_factory = sprites_factory
    if openrouter_factory is not None:
        args.openrouter_factory = openrouter_factory
    env = os.environ if env is None else env
    try:
        validate_export(env)
    except ValueError as exc:
        (err or sys.stderr).write(f"atlas_reviewer: {exc}\n")
        return EXIT_USAGE
    run = _Run(env, out or sys.stdout, err or sys.stderr, _Credentials(env))
    shared_trace(env, run.credentials.scrub)
    handler: Callable[[argparse.Namespace, _Run], int] = args.handler
    try:
        code = handler(args, run)
    except tuple(e for e, _ in _ERRORS) as exc:
        run.err.write(f"atlas_reviewer: {run.credentials.scrub(str(exc))}\n")
        if run.telemetry is not None:
            run.err.write(_telemetry_line(run, run.telemetry))
        code = next(mapped for kind, mapped in _ERRORS if isinstance(exc, kind))
    finally:
        # The review raises a held stop right after its runner phase.
        # One still pending here is a command that ended in an error,
        # including an exception this handler does not map.
        shutdown_shared()
        raise_if_stopped()
    return code
