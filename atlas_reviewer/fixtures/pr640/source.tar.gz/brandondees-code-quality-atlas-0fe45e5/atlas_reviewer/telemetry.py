# SPDX-License-Identifier: MIT
"""Lifecycle telemetry: one structured event per step of a review or probe.

Every event is kept in memory for the summary table that the draft and
`probe-runner` print, up to 500 events, and goes to one `EventSink` (a
JSONL file in live use, nothing in tests). Past that cap the oldest
in-memory events are dropped. An event recorded after the sink has
closed stays in memory only. Field values are numbers,
booleans or labels the controller chose. Free text (error messages, which
can quote URLs or runner output) goes through `scrub`, the controller's
redactor, before any sink sees it, so no event carries a credential; a
sink cannot be attached without one.

`span` times one step. A `BoundaryError` raised inside it is re-raised as
the same object, its message prefixed with the phase, the step, how long
the step took and how far into the run it failed, so no failure surfaces
as a bare "The read operation timed out". The innermost span labels the
error; any enclosing span records its own event but keeps that label.
Raising the same object again later labels it afresh, never stacking
labels.
"""

from __future__ import annotations

import itertools
import json
import os
import threading
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, Self, TextIO

from atlas_reviewer.ledger import make_private_dirs
from atlas_reviewer.ports import BoundaryError, Clock
from atlas_reviewer.redact import redact

FieldValue = str | int | float | bool | None
Fields = Mapping[str, FieldValue]
OK, ERROR = "ok", "error"
_LABELLED_AT = "atlas_step_labelled_at"
_UNLABELLED = "atlas_step_unlabelled"
_SPAN_SEQUENCE = itertools.count()


@dataclass(frozen=True)
class Event:
    seq: int
    phase: str
    step: str
    status: str
    start_s: float
    duration_s: float
    fields: Fields = field(default_factory=dict)
    error: str = ""

    def as_json(self) -> dict[str, FieldValue]:
        head: dict[str, FieldValue] = {
            "seq": self.seq,
            "phase": self.phase,
            "step": self.step,
            "status": self.status,
            "start_s": self.start_s,
            "duration_s": self.duration_s,
        }
        return {**head, **self.fields, **({"error": self.error} if self.error else {})}


class EventSink(Protocol):
    def emit(self, event: Event) -> None: ...


class NullSink:
    def emit(self, event: Event) -> None:
        return None


class JsonlSink:
    """Appends one JSON object per line through one descriptor, held from
    entering the sink as a context manager until it exits, and flushes
    each line, so a crashed or killed run still leaves every event up to
    the crash on disk. Holding the descriptor means a file deleted
    mid-run is never recreated outside its claim. A file it creates is
    0600, and each directory it creates 0700."""

    def __init__(self, path: Path, *, max_bytes: int | None = None) -> None:
        self.path = path
        self._max_bytes = max_bytes
        self._out: TextIO | None = None
        self._closed = False
        self._lock = threading.Lock()

    def __enter__(self) -> Self:
        make_private_dirs(self.path.parent)
        fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        self._out = os.fdopen(fd, "a", encoding="utf-8")
        return self

    def __exit__(self, *_exc: object) -> None:
        # The same lock as `emit`: the runner watchdog can still be
        # writing when the CLI leaves this sink, and a close landing
        # mid-write would raise on that thread.
        with self._lock:
            if self._out is not None:
                self._out.close()
                self._out = None
            self._closed = True

    def emit(self, event: Event) -> None:
        with self._lock:
            if self._out is None:
                # Closed, not merely unopened. `runner.py` returns from the
                # final destroy while the watchdog may still be inside
                # delete; that late record is dropped, not raised.
                if self._closed:
                    return
                raise RuntimeError(f"telemetry sink {self.path} is not open")
            if self._max_bytes is not None and self._out.tell() >= self._max_bytes:
                self._rotate()
            assert self._out is not None
            self._out.write(json.dumps(event.as_json()) + "\n")
            self._out.flush()

    def _rotate(self) -> None:
        """Called with the sink lock held. Keeps one previous file."""
        if self._out is not None:
            self._out.close()
            self._out = None
        backup = self.path.with_name(self.path.name + ".1")
        if backup.exists():
            backup.unlink()
        if self.path.exists():
            os.replace(self.path, backup)
        make_private_dirs(self.path.parent)
        fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        self._out = os.fdopen(fd, "a", encoding="utf-8")


def _redact_shapes(text: str) -> str:
    return redact(text).text


def _no_fields(_result: object) -> Fields:
    return {}


class Telemetry:
    """Thread-safe: the runner watchdog destroys from its own thread.

    Writing events anywhere needs `scrub`, the controller's redactor bound
    to its own credentials. Without a sink, events stay in memory and are
    still scrubbed of secret-shaped values by pattern."""

    def __init__(
        self,
        clock: Clock,
        sink: EventSink | None = None,
        scrub: Callable[[str], str] | None = None,
        max_kept: int = 500,
    ) -> None:
        if sink is not None and scrub is None:
            raise TypeError(
                "a telemetry sink needs scrub, the controller's redactor bound "
                "to its credentials"
            )
        self._clock = clock
        self._sink = sink or NullSink()
        self._scrub = scrub or _redact_shapes
        self._start = clock.monotonic()
        self._events: list[Event] = []
        self._seq = 0
        # The in-memory list feeds the draft summary. A long-lived process
        # keeps only the newest events; the sink has the rest.
        self._max_kept = max_kept
        self._lock = threading.Lock()

    @property
    def sink(self) -> EventSink:
        return self._sink

    @property
    def events(self) -> tuple[Event, ...]:
        with self._lock:
            return tuple(self._events)

    def elapsed(self) -> float:
        return self._clock.monotonic() - self._start

    def scrub(self, text: str) -> str:
        """The same redaction events get, for text leaving by another way
        (a runner report's note)."""
        return self._scrub(text)

    def record(
        self,
        phase: str,
        step: str,
        fields: Fields | None = None,
        *,
        status: str = OK,
        start_s: float | None = None,
        error: str = "",
    ) -> Event:
        start = self.elapsed() if start_s is None else start_s
        duration = max(self.elapsed() - start, 0.0)
        clean = {k: self._clean(v) for k, v in (fields or {}).items()}
        with self._lock:
            self._seq += 1
            event = Event(
                self._seq,
                phase,
                step,
                status,
                round(start, 3),
                round(duration, 3),
                clean,
                self._scrub(error),
            )
            self._events.append(event)
            if len(self._events) > self._max_kept:
                del self._events[: len(self._events) - self._max_kept]
            self._sink.emit(event)
        return event

    def span[T](
        self,
        phase: str,
        step: str,
        fn: Callable[[], T],
        fields: Fields | None = None,
        after: Callable[[T], Fields] = _no_fields,
    ) -> T:
        start, opened = self.elapsed(), next(_SPAN_SEQUENCE)
        try:
            result = fn()
        except BoundaryError as exc:
            _label(exc, phase, step, start, self.elapsed(), opened)
            self.record(
                phase, step, fields, status=ERROR, start_s=start, error=str(exc)
            )
            raise
        except Exception as exc:
            self.record(
                phase, step, fields, status=ERROR, start_s=start,
                error=f"{type(exc).__name__}: {exc}",
            )  # fmt: skip
            raise
        self.record(phase, step, {**(fields or {}), **after(result)}, start_s=start)
        return result

    def _clean(self, value: FieldValue) -> FieldValue:
        return self._scrub(value) if isinstance(value, str) else value


def _label(
    exc: BoundaryError, phase: str, step: str, start: float, now: float, opened: int
) -> None:
    """Relabels `exc` itself rather than building a copy: a copy loses the
    attributes a subclass promises (`StreamTimeoutError.received`) and
    cannot be built at all when its constructor needs more arguments.

    A label added after this span opened came from a span nested in it, so
    the innermost label stands. One added before it opened is from an
    earlier raise of the same object (a fake or caching adapter), so this
    span relabels it, from the message as first raised."""
    labelled_at = getattr(exc, _LABELLED_AT, None)
    if labelled_at is not None and labelled_at > opened:
        return
    if labelled_at is None:
        setattr(exc, _UNLABELLED, str(exc))
    prefix = (
        f"{phase} / {step} failed after {now - start:.1f}s ({now:.1f}s into the run): "
    )
    exc.args = (f"{prefix}{getattr(exc, _UNLABELLED)}",)
    setattr(exc, _LABELLED_AT, next(_SPAN_SEQUENCE))


SUMMARY_HEADERS = (
    "#",
    "Phase",
    "Step",
    "Status",
    "Start (s)",
    "Duration (s)",
    "Detail",
)


def summary_rows(events: tuple[Event, ...]) -> tuple[tuple[str, ...], ...]:
    return tuple(
        (
            str(e.seq),
            e.phase,
            e.step,
            e.status.upper() if e.status == ERROR else e.status,
            f"{e.start_s:.1f}",
            f"{e.duration_s:.1f}",
            _detail(e),
        )
        for e in events
    )


def _detail(event: Event) -> str:
    pairs = "; ".join(f"{k}={v}" for k, v in event.fields.items())
    return "; ".join(part for part in (pairs, event.error) if part)
