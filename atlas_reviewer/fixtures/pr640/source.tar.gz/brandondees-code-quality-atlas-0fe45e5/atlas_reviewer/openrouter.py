# SPDX-License-Identifier: MIT
"""Live OpenRouter model provider, pinned to the approved pilot settings.

- Model `anthropic/claude-sonnet-5.5` only: no `models` fallback list, no
  plugins, no web search, and a response from any other model is rejected.
- Provider routing is pinned (`provider.only`, `allow_fallbacks: false`,
  `require_parameters`, `zdr`, `data_collection: deny`, and `max_price` at
  the catalog's highest prices) per
  https://openrouter.ai/docs/guides/routing/provider-selection (fetched
  2026-11-07). That page's "Base Slug Matching" says a bare provider slug
  in `only` matches every eligible endpoint of that provider, regions
  included. A read-only check of the public provider list the same day
  found no bare `google-vertex` endpoint, only `google-vertex/global`,
  `google-vertex/us`, and `google-vertex/europe`, and found Amazon Bedrock
  as the base slug `amazon-bedrock` plus region slugs it did not name.
  `PINNED_PROVIDERS` is exactly those named slugs. A slug outside
  `LISTED_PROVIDER_SLUGS` is refused before any request, so a doc example
  (`google-vertex/us-east5`, `amazon-bedrock/eu-west-1`) or the bare
  Vertex slug cannot widen routing. Bedrock's unnamed region slugs are
  not pinned. https://openrouter.ai/docs/guides/features/in-region-routing
  ("Regional Endpoints on the Global Domain") says a bare
  `amazon-bedrock` does not pin that provider's regional-surcharge
  endpoints.
- `preflight()` must pass before any inference: it reads the key's own
  status (`GET /api/v1/key`) and refuses unless the key has a hard credit
  limit of at most `KEY_LIMIT_MAX_USD`, with credit left. A key whose
  `include_byok_in_limit` is false or absent is accepted.
- Before each completion the public catalog entry is re-fetched (without
  the key) and every limit is checked in code before a request is sent;
  each attempt, retries included, reserves its worst-case cost in a
  per-review `ReviewBudget` first, capped at the lower of the review
  budget and the key's remaining credit as read by the preflight. Actual usage and cost are read from the
  response's `usage` object.
- The key's own usage counter (`GET /api/v1/key`) is read once, by the
  preflight, and never after inference. It can lag a completion by about 90
  seconds (one owner-reported pilot observation, not checked against
  OpenRouter's documentation), so a $0 readback right after a call is
  expected and is not a mismatch with the per-response cost recorded here.
  Spend is reconciled from the response, never from that counter.
  Settlement rule. When `usage.is_byok` is boolean false, the call settles
  `usage.cost` and a reported `cost_details.upstream_inference_cost` is not
  added, with two over-counts: an upstream amount larger than `usage.cost`
  settles at that amount, and an upstream value that is present, not null
  and unreadable keeps the full reservation. A null or absent upstream
  settles `usage.cost`; with no usable `usage.cost` it is priced from the
  highest catalog rates, or, when the response reports cache read or
  write counts, with those counts at the catalog's cache rates
  (`_prompt_cost`), and upstream is still not added. For any other
  `is_byok` value a reported upstream cost is added. A call with `is_byok`
  true and no upstream cost keeps its full reservation. A present,
  non-null, unreadable upstream value keeps the reservation on any
  response, including an explicitly non-BYOK one. A null upstream
  keeps the reservation unless `is_byok` is exactly false. The
  settlement line records the raw upstream value on an explicit
  non-BYOK call, cut to 200 characters.
  The SDK says that on a BYOK request `cost` is the OpenRouter fee only
  (https://openrouter.ai/docs/client-sdks/typescript/models/decisionsresponseusage,
  fetched 2026-11-11). The usage-accounting page calls `cost` the total
  charged to the account and does not say whether a non-BYOK `cost`
  already includes the upstream amount
  (https://openrouter.ai/docs/cookbook/administration/usage-accounting,
  fetched 2026-11-11) (verify). The rule is policy: on PR #585 (2026-11-11)
  the key charge equalled `usage.cost` and the previous sum settled twice
  that. A key whose `include_byok_in_limit` is not true passes preflight
  and the run is in no-BYOK mode: a response is used only when
  `usage.is_byok` is boolean false. True, a missing field, any other
  value, or an HTTP 200 whose body cannot be parsed raises
  `ByokRefusedError` after the call is settled, so the review stops
  before another model call. OpenRouter's usage cookbook shows
  `is_byok: false` on its Responses API example and omits the field from
  its Chat Completions example, and the SDK types it as optional
  (https://openrouter.ai/docs/cookbook/administration/usage-accounting,
  fetched 2026-11-11), so a missing field is not evidence the call was
  non-BYOK.
"""

from __future__ import annotations

import json
import math
import re
from collections.abc import Callable, Sequence
from decimal import Decimal
from typing import Any, NoReturn

from atlas_reviewer.budget import (
    BudgetRefusedError,
    CallLimits,
    CallRecord,
    ReviewBudget,
    check_tokens,
    input_token_bound,
    worst_case_usd,
)
from atlas_reviewer.http import HttpResponse, Transport, safe_url
from atlas_reviewer.ports import BoundaryError, ByokRefusedError, Json
from atlas_reviewer.pricing import (
    KeyStatus,
    ModelTerms,
    PricingUnknownError,
    money,
    parse_key_status,
    parse_model_terms,
)
from atlas_reviewer.prompt import Prompt

API_URL = "https://openrouter.ai/api/v1"
MODEL_ID = "anthropic/claude-sonnet-5.5"
# Slugs named by the 2026-11-07 public-list check and the routing docs.
# Not an inventory of every Bedrock region: those were reported, not named.
LISTED_PROVIDER_SLUGS = frozenset(
    {
        "amazon-bedrock",
        "google-vertex/europe",
        "google-vertex/global",
        "google-vertex/us",
    }
)
PINNED_PROVIDERS = (
    "amazon-bedrock",
    "google-vertex/europe",
    "google-vertex/global",
    "google-vertex/us",
)
KEY_LIMIT_MAX_USD = Decimal("5.00")
RETRYABLE = frozenset({408, 429, 500, 502, 503, 504})
_PER_MILLION = Decimal(1_000_000)
# A numeric Retry-After above this waits this long; the 3-call cap still bounds
# how many waits a review can make.
_MAX_RETRY_WAIT = 8.0


def _require_listed(slugs: Sequence[str]) -> tuple[str, ...]:
    """Refuse before any request when a slug is not on the reviewed list.

    An empty allowlist is refused too: `only: []` would drop the pin.
    """
    if not slugs:
        raise BudgetRefusedError("refusing inference: provider allowlist is empty")
    unknown = [slug for slug in slugs if slug not in LISTED_PROVIDER_SLUGS]
    if unknown:
        raise BudgetRefusedError(
            "refusing unlisted provider slugs: " + ", ".join(unknown)
        )
    return tuple(dict.fromkeys(slugs))


class OpenRouterProvider:
    name = f"openrouter:{MODEL_ID}"

    def __init__(
        self,
        transport: Transport,
        api_key: str,
        *,
        limits: CallLimits | None = None,
        api_url: str = API_URL,
        timeout_s: float = 300.0,
        sleep: Callable[[float], None] = lambda _s: None,
        providers: Sequence[str] = PINNED_PROVIDERS,
    ) -> None:
        self._transport = transport
        self._key = api_key
        self._api_url = api_url.rstrip("/")
        self._timeout_s = timeout_s
        self._sleep = sleep
        self._providers = _require_listed(providers)
        self.budget = ReviewBudget(limits or CallLimits())
        self._key_status: KeyStatus | None = None

    def preflight(self) -> KeyStatus:
        status = parse_key_status(self._get_json("/key", authed=True))
        if status.limit > KEY_LIMIT_MAX_USD:
            raise PricingUnknownError(
                f"the OpenRouter key's credit limit ${status.limit} is over the "
                f"${KEY_LIMIT_MAX_USD} pilot ceiling"
            )
        if status.limit_remaining <= 0:
            raise PricingUnknownError("the OpenRouter key has no credit remaining")
        self._key_status = status
        return status

    def usage_lines(self) -> tuple[str, ...]:
        return (f"model `{MODEL_ID}` via OpenRouter", *self.budget.report())

    def complete(self, prompt: Prompt) -> str:
        if self._key_status is None:
            self._refused(
                BudgetRefusedError("refusing inference: key preflight has not passed")
            )
        try:
            terms = parse_model_terms(self._get_json(f"/model/{MODEL_ID}"), MODEL_ID)
        except PricingUnknownError as exc:
            self._refused(exc)
        tokens = input_token_bound(prompt.system + prompt.user)
        try:
            check_tokens(tokens, terms, self.budget.limits)
        except BudgetRefusedError as exc:
            self._refused(exc)
        worst = worst_case_usd(tokens, terms, self.budget.limits)
        return self._attempts(self._body(prompt, terms), terms, worst)

    def _refused(self, exc: BoundaryError) -> NoReturn:
        """Record a refusal that spent nothing and was not sent, then raise it."""
        self.budget.refusals.append(str(exc))
        raise exc

    def _attempts(self, body: bytes, terms: ModelTerms, worst: Decimal) -> str:
        remaining = self._key_status.limit_remaining if self._key_status else Decimal(0)
        last: BoundaryError | None = None
        retry_after: str | None = None
        for attempt in range(self.budget.limits.max_calls):
            if attempt:
                self._sleep(_retry_wait(retry_after, attempt))
            try:
                record = self.budget.reserve(worst, ceiling_usd=remaining)
            except BudgetRefusedError as refusal:
                raise (last or refusal) from refusal
            result = self._send(body, terms, record)
            if isinstance(result, str):
                return result
            last, retry_after = result
        raise last or BoundaryError("no model call was made")

    def _send(
        self, body: bytes, terms: ModelTerms, record: CallRecord
    ) -> str | tuple[BoundaryError, str | None]:
        url = f"{self._api_url}/chat/completions"
        try:
            resp = self._transport.request(
                "POST",
                url,
                self._headers(authed=True, json_body=True),
                body,
                self._timeout_s,
            )
        except BoundaryError as exc:
            ReviewBudget.settle(record, f"transport error: {exc}")
            return exc, None
        if resp.status in RETRYABLE:
            ReviewBudget.settle(record, f"HTTP {resp.status} (retryable)")
            return (
                BoundaryError(f"OpenRouter HTTP {resp.status} for {safe_url(url)}"),
                resp.header("Retry-After"),
            )
        if resp.status != 200:
            ReviewBudget.settle(record, f"HTTP {resp.status}")
            raise BoundaryError(f"OpenRouter HTTP {resp.status} for {safe_url(url)}")
        counts_byok = self._key_status.counts_byok if self._key_status else False
        return _completion(resp, terms, record, counts_byok=counts_byok)

    def _body(self, prompt: Prompt, terms: ModelTerms) -> bytes:
        limits = self.budget.limits
        payload = {
            "model": MODEL_ID,
            "messages": [
                {"role": "system", "content": prompt.system},
                {"role": "user", "content": prompt.user},
            ],
            "max_tokens": limits.max_output_tokens,
            "reasoning": {"max_tokens": limits.reasoning_max_tokens, "exclude": True},
            "stream": False,
            "provider": {
                "only": list(self._providers),
                "allow_fallbacks": False,
                "require_parameters": True,
                "data_collection": "deny",
                "zdr": True,
                "max_price": {
                    "prompt": float(terms.prompt_rate * _PER_MILLION),
                    "completion": float(terms.completion_rate * _PER_MILLION),
                },
            },
        }
        return json.dumps(payload).encode()

    def _headers(self, *, authed: bool, json_body: bool = False) -> dict[str, str]:
        headers = {
            "User-Agent": "code-quality-atlas-reviewer",
            "Accept": "application/json",
        }
        if authed:
            headers["Authorization"] = f"Bearer {self._key}"
        if json_body:
            headers["Content-Type"] = "application/json"
        return headers

    def _get_json(self, path: str, *, authed: bool = False) -> Json:
        url = f"{self._api_url}{path}"
        resp = self._transport.request(
            "GET", url, self._headers(authed=authed), None, self._timeout_s
        )
        if resp.status != 200:
            raise PricingUnknownError(
                f"OpenRouter HTTP {resp.status} for {safe_url(url)}"
            )
        return _json_object(resp.body, safe_url(url), PricingUnknownError)


def _retry_wait(header: str | None, attempt: int) -> float:
    """Seconds before the next attempt: a numeric Retry-After, capped, else
    exponential backoff. An HTTP-date or a negative value is not numeric."""
    backoff = 2.0**attempt
    if header is None:
        return backoff
    try:
        seconds = float(header.strip())
    except ValueError:
        return backoff
    if seconds < 0 or not math.isfinite(seconds):
        return backoff
    return min(seconds, _MAX_RETRY_WAIT)


def _json_object(raw: bytes, where: str, error: type[BoundaryError]) -> Json:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise error(f"non-JSON response from {where}") from None
    if not isinstance(data, dict):
        raise error(f"non-object response from {where}")
    return data


def _completion(
    resp: HttpResponse, terms: ModelTerms, record: CallRecord, *, counts_byok: bool
) -> str:
    try:
        data = _json_object(resp.body, "OpenRouter chat completion", BoundaryError)
    except BoundaryError:
        ReviewBudget.settle(record, "unparseable response")
        if not counts_byok:
            raise ByokRefusedError(
                "refusing the review: this OpenRouter key does not count BYOK "
                "spend against its credit limit, and the response could not be "
                "parsed, so is_byok could not be checked"
            ) from None
        raise
    usage = data.get("usage")
    usage_obj = usage if isinstance(usage, dict) else {}
    if not counts_byok:
        _refuse_unless_explicitly_non_byok(usage_obj, terms, record)
    actual, summary = _actual_cost(usage_obj, terms)
    served = data.get("model")
    if not isinstance(served, str) or not _is_pinned_model(served):
        ReviewBudget.settle(record, f"rejected: served by {served!r}", actual, summary)
        raise BoundaryError(f"OpenRouter served {served!r}, not {MODEL_ID}")
    text, finish = _message(data)
    if not text.strip():
        ReviewBudget.settle(
            record, f"empty review (finish_reason={finish})", actual, summary
        )
        raise BoundaryError(f"model returned no review text (finish_reason={finish})")
    if finish != "stop":
        ReviewBudget.settle(
            record, f"incomplete review (finish_reason={finish})", actual, summary
        )
        if finish == "length":
            raise BoundaryError("model review stopped at the output-token limit")
        raise BoundaryError(f"model review did not finish (finish_reason={finish})")
    ReviewBudget.settle(record, f"ok (finish_reason={finish})", actual, summary)
    return text


_DATED_REVISION = re.compile(re.escape(MODEL_ID) + r"-\d{8}")


def _is_pinned_model(served: str) -> bool:
    return served == MODEL_ID or _DATED_REVISION.fullmatch(served) is not None


def _message(data: Json) -> tuple[str, str]:
    choices = data.get("choices")
    first: Any = choices[0] if isinstance(choices, list) and choices else {}
    message = first.get("message") if isinstance(first, dict) else None
    content = message.get("content") if isinstance(message, dict) else None
    finish = first.get("finish_reason") if isinstance(first, dict) else None
    return (content if isinstance(content, str) else ""), str(finish)


def _refuse_unless_explicitly_non_byok(
    usage: Json, terms: ModelTerms, record: CallRecord
) -> None:
    """No-BYOK mode. Only boolean false is a non-BYOK response. True, a
    missing field, or any other value ends the review. The call is settled
    first, as a BYOK call would be, so an unreported upstream charge keeps
    the full reservation."""
    reason = _no_byok_reason(usage)
    if reason is None:
        return
    marked = usage if usage.get("is_byok") is True else {**usage, "is_byok": True}
    actual, summary = _actual_cost(marked, terms)
    ReviewBudget.settle(record, f"refused: {reason}", actual, summary)
    raise ByokRefusedError(
        "refusing the review: this OpenRouter key does not count BYOK spend "
        f"against its credit limit, and {reason}"
    )


def _no_byok_reason(usage: Json) -> str | None:
    if "is_byok" not in usage:
        return "the response usage has no is_byok field"
    flag = usage["is_byok"]
    if flag is False:
        return None
    if flag is True:
        return "the response usage.is_byok is true"
    return "the response usage.is_byok is not false"


def _prompt_cost(
    usage: Json, terms: ModelTerms, prompt_t: int
) -> tuple[Decimal | None, str]:
    """Price prompt tokens when `usage.cost` is absent.

    With no cache counts, every prompt token is charged at `input_rate`,
    which is already the higher of the prompt rate and any cache-write
    rate. When the response reports cache reads or writes, those counts
    are subsets of `prompt_tokens`: reads are charged at the catalog's
    cache-read rate (or the prompt rate when the catalog has none), and
    writes at the catalog's cache-write rate (or `input_rate` when the
    catalog has none). The rest are charged at the prompt rate when the
    write count is reported. When it is absent, a write could be hiding
    in the rest, so the rest is charged at `input_rate`. Counts that sum
    past `prompt_tokens` are not a usable split, and the turn stays
    unpriced."""
    details = usage.get("prompt_tokens_details")
    if not isinstance(details, dict):
        return prompt_t * terms.input_rate, ""
    if any(
        details.get(key) is not None and _tokens(details, key) is None
        for key in ("cached_tokens", "cache_write_tokens")
    ):
        return None, ""
    cached = _tokens(details, "cached_tokens")
    written = _tokens(details, "cache_write_tokens")
    if cached is None and written is None:
        return prompt_t * terms.input_rate, ""
    cached_n = 0 if cached is None else cached
    read_rate = (
        terms.prompt_rate if terms.cache_read_rate is None else terms.cache_read_rate
    )
    if written is None:
        if cached_n > prompt_t:
            return None, ""
        cost = cached_n * read_rate + (prompt_t - cached_n) * terms.input_rate
        return cost, f" cache_read={cached_n} cache_write=unreported"
    if cached_n + written > prompt_t:
        return None, ""
    fresh = prompt_t - cached_n - written
    write_rate = (
        terms.input_rate if terms.cache_write_rate is None else terms.cache_write_rate
    )
    cost = fresh * terms.prompt_rate + cached_n * read_rate + written * write_rate
    return cost, f" cache_read={cached_n} cache_write={written}"


def _tokens(usage: Json, key: str) -> int | None:
    value = usage.get(key)
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value
    return None


def _actual_cost(usage: Json, terms: ModelTerms) -> tuple[Decimal | None, str]:
    prompt_t, completion_t = (
        _tokens(usage, "prompt_tokens"),
        _tokens(usage, "completion_tokens"),
    )
    details = usage.get("completion_tokens_details")
    reasoning_t = (
        _tokens(details, "reasoning_tokens") if isinstance(details, dict) else None
    )
    summary = f"tokens in={prompt_t} out={completion_t} reasoning={reasoning_t}"
    # Policy: boolean false settles usage.cost. OpenRouter's docs do not
    # say whether that cost already includes the upstream amount (verify).
    # PR #585 (2026-11-11) charged usage.cost and the old sum settled twice
    # that. Ambiguity over-counts: an upstream amount above usage.cost, or
    # one that is present and unreadable, is never settled below what it
    # could cost.
    explicitly_non_byok = usage.get("is_byok") is False
    raw = _upstream_raw(usage)
    try:
        upstream = _upstream_cost(raw, null_is_absent=explicitly_non_byok)
    except PricingUnknownError:
        if explicitly_non_byok:
            summary += f" (upstream {_shown(raw)} unreadable)"
        return None, summary
    if usage.get("is_byok") is True and upstream is None:
        return None, f"{summary} (BYOK upstream cost not reported)"
    from_usage_cost = True
    try:
        base = money(usage["cost"], "usage.cost")
    except (KeyError, PricingUnknownError):
        from_usage_cost = False
        if prompt_t is None or completion_t is None:
            return None, summary
        if terms.reasoning_rate > 0 and reasoning_t is None:
            return None, summary
        prompt_cost, cache_note = _prompt_cost(usage, terms, prompt_t)
        if prompt_cost is None:
            return None, summary
        reasoning = (reasoning_t or 0) * terms.reasoning_rate
        base = (
            prompt_cost
            + completion_t * terms.completion_rate
            + reasoning
            + terms.request_fee
        )
        rates = "catalog rates" if cache_note else "the highest catalog rates"
        summary = f"{summary}{cache_note} (cost computed at {rates})"
    if not explicitly_non_byok:
        if upstream is not None:
            base += upstream
    elif raw is not _ABSENT:
        if from_usage_cost and upstream is not None and upstream > base:
            summary += (
                f" (upstream {_shown(raw)} exceeds usage.cost {base}:"
                " settled at upstream)"
            )
            base = upstream
        else:
            summary += f" (upstream {_shown(raw)} reported, not added: is_byok false)"
    return base, summary


_ABSENT: Any = object()


def _upstream_raw(usage: Json) -> Any:
    """The reported `cost_details.upstream_inference_cost`, or `_ABSENT`."""
    details = usage.get("cost_details")
    if not isinstance(details, dict) or "upstream_inference_cost" not in details:
        return _ABSENT
    return details["upstream_inference_cost"]


def _upstream_cost(raw: Any, *, null_is_absent: bool) -> Decimal | None:
    """`raw` as money. Absent is None. A null is None only when the caller
    says so; any other value that cannot be read raises."""
    if raw is _ABSENT or (raw is None and null_is_absent):
        return None
    return money(raw, "usage.cost_details.upstream_inference_cost")


def _shown(raw: Any) -> str:
    return f"{raw!r:.200}"
