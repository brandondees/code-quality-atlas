---
name: auditing-a-repository
description: Run a whole-repository health audit with the code-quality-atlas repo-shaped
  audits (architecture, dependencies, config/build, docs, compliance, enforcement,
  infrastructure-as-code, decision-record currency, data-pipeline health, deployment/execution
  and trust-boundary security, maintainability hotspots). Use for a scheduled or on-demand
  repo audit, not a single diff. Runs the applicable audits and synthesizes one report.
provenance:
  taxonomy_version: v0.14
  built_from: []
---

# auditing-a-repository

## When to use

Run a whole-repository health audit with the code-quality-atlas repo-shaped audits (architecture, dependencies, config/build, docs, compliance, enforcement, infrastructure-as-code, decision-record currency, data-pipeline health, deployment/execution and trust-boundary security, maintainability hotspots). Use for a scheduled or on-demand repo audit, not a single diff. Runs the applicable audits and synthesizes one report.

## How this works

Rank the relevant lenses below by relevance to what is being reviewed, pick the breadth from the depth mode (default **review**), then for each selected lens **load its bundle** and apply it:

- Before the lenses judge anything, gather deterministic evidence with the procedure in `reference/tool-evidence.md` — run the linters, type checkers, and scanners this repo *already* configures, scoped to what's under review, and hand each lens its hits. Skip it when the repo configures none, or when running them would execute untrusted code; say so in the coverage line either way.
- Read `reference/lenses/<lens>/body.md` — the lens's checklist and examples. Open `reference/lenses/<lens>/tool-rules.md` or `sources.md` only if deeper tooling/provenance is called for.
- **A finding written in a lens's voice is valid only if that lens's `body.md` was actually read this round.** The one-line description in the Lenses list below exists to rank and select lenses, not to write findings in their style — it is specific enough on its own to produce a fluent, plausible-sounding finding for a lens whose bundle was never opened (issue #357). Selecting N lenses and loading only one, then backfilling the rest from their one-liners, reads identically to a review that ran every checklist. If a selected lens's `body.md` was not opened, it did not run: drop any finding attributed to it and say so in the coverage line instead.
- After the lenses run, merge their findings with the procedure in `reference/synthesis.md` — one deduplicated, ranked report with a single verdict.

## Depth modes

Routing first ranks **every** lens in scope by **relevance**, with no hard cap on the ranking itself — for a single change, scope is what the diff touches; for a whole-repo audit, scope is the repository. A depth mode then sets the **breadth** (how far down the ranked list to run, plus room for judgment calls above that floor) and the severity floor. Pick the mode from the request; default to **review**.

| Mode | Breadth | Triggers |
|---|---|---|
| **triage** | the critical tier only — correctness, security, data-safety, and concurrency | "triage", "quick review", "fast check", "pre-merge gate" |
| **review** | the top 3-8 lenses by relevance, plus any additional relevant lenses the reviewer judges worthwhile (the default; not a strict cap) | "review", "review this", "code review", "review this PR", "review the diff" |
| **comprehensive** | every relevant lens, uncapped — the full audit set at repo scope | "thorough", "comprehensive", "deep review", "use all relevant lenses", "review everything" |

- **triage** — A pre-merge gate: run only the critical-tier lenses and report Major and above.
- **review** — Default per-PR depth: relevance-ranked top-N (3-8) with the round-based escalating floor; extend past N when the change's scope genuinely calls for another lens.
- **comprehensive** — On-demand or scheduled: run all relevant lenses and pin the floor at Nit so readability-class and other long-tail findings surface instead of being trimmed.

## Routes

| When reviewing… | Run |
|---|---|
| Whole-repo health audit (scheduled / cron) | `finding-maintainability-hotspots`, `auditing-architecture-conformance`, `auditing-dependencies-and-supply-chain`, `auditing-config-and-build-hygiene`, `auditing-documentation-health`, `auditing-compliance-and-provenance`, `auditing-enforcement-and-meta-artifacts`, `auditing-infrastructure-as-code`, `auditing-decision-record-currency`, `auditing-data-pipeline-health`, `auditing-deployment-and-trust-boundaries` — the eleven repo-shaped audits; run independently, not as one pass (auditing-infrastructure-as-code only where IaC manifests exist; auditing-decision-record-currency only where a decision-record directory exists; auditing-data-pipeline-health only where the repo has SQL models, pipelines, data tests, or published data schemas — data tests included because a repo can carry permanently-warning or disabled ones with no models of its own; auditing-deployment-and-trust-boundaries only where the repo has deployment automation, a scheduled job, an unattended sync/execute pattern, service-to-service trust config, or an agent-triggerable hook/helper script to examine) |
| Enforcement config — lint/type suppressions, alert rules or dashboards, or checked-in generated artifacts | `auditing-enforcement-and-meta-artifacts` — repo-shaped — scans suppression accretion and codegen/monitoring drift across the tree, not a single diff |
| A repository's existing decision-record archive (an ADR/RFC directory already on disk), swept on a schedule rather than reviewed as it's being authored | `auditing-decision-record-currency` — repo-shaped — status-graph consistency, revisit-triggers plausibly due, EOL adoptions, and orphaned records; #29 owns the authoring-time call, this only checks whether time has invalidated an existing one |

## Lenses

◆ = design-capable.

- [`finding-maintainability-hotspots`](reference/lenses/finding-maintainability-hotspots/body.md) — Where does the repo hurt most? Churn × complexity, change-coupling, bus factor, untracked debt.
- [`auditing-data-pipeline-health`](reference/lenses/auditing-data-pipeline-health/body.md) — Has the data plane drifted since anyone looked? Contract currency, test coverage by fan-out, lapsed freshness, expired deprecations, hidden lineage.
- [`auditing-architecture-conformance`](reference/lenses/auditing-architecture-conformance/body.md) — Does the import graph still match the intended architecture? Layers, cycles, reach-arounds.
- [`auditing-dependencies-and-supply-chain`](reference/lenses/auditing-dependencies-and-supply-chain/body.md) — Is the dependency tree safe? CVEs, pinning, typosquats, install scripts, licenses.
- [`auditing-config-and-build-hygiene`](reference/lenses/auditing-config-and-build-hygiene/body.md) — Are config and CI trustworthy? Secrets, env parity, reproducible pinned builds, cache correctness.
- [`auditing-documentation-health`](reference/lenses/auditing-documentation-health/body.md) — Do the docs still tell the truth? API parity, stale examples, ADR coverage, changelog discipline.
- [`auditing-compliance-and-provenance`](reference/lenses/auditing-compliance-and-provenance/body.md) — Any licensing, PII, or provenance exposure? Detect and escalate to humans — never decide legal questions.
- [`auditing-decision-record-currency`](reference/lenses/auditing-decision-record-currency/body.md) — Do the repo's existing decision records still hold? Status-graph consistency, revisit-triggers due, EOL adoptions, orphaned records.
- [`auditing-enforcement-and-meta-artifacts`](reference/lenses/auditing-enforcement-and-meta-artifacts/body.md) — Is the enforcement apparatus healthy? Suppression hygiene & baseline trend, actionable alerts/monitoring-as-code, codegen-source drift gate.
- [`auditing-infrastructure-as-code`](reference/lenses/auditing-infrastructure-as-code/body.md) — Does this infra change expose or destroy something? Blast radius, public access, wildcard IAM, secrets in state, drift.
- [`auditing-deployment-and-trust-boundaries`](reference/lenses/auditing-deployment-and-trust-boundaries/body.md) — Could an adversary reach code execution or persistence through the deployment wiring itself, not a vulnerable line of code?

<!-- GENERATED by `python -m tooling.cli generate` — do not edit this file directly.
     Canonical sources: skills/manifest.yaml.
     Direct edits are overwritten on regeneration and fail the CI drift/regenerate gate. -->
