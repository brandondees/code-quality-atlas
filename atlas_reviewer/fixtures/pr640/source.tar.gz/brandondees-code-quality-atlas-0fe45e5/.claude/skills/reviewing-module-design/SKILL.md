---
name: reviewing-module-design
description: 'Reviews module and type design: cohesion and coupling (via connascence),
  encapsulation, hard-to-misuse interfaces, and making illegal states unrepresentable.
  Use when reviewing class/module structure, interfaces, type or data modeling, coupling,
  or API ergonomics for callers.'
provenance:
  taxonomy_version: v0.14
  built_from:
  - category: 9
    source: docs/research/cluster-3-structure.md#9
    hash: dc30b39084a3f2f128ecfc0a318c1a4a69aa24afc3c87d4f3b2064e54a5e6023
  - category: 10
    source: docs/research/cluster-3-structure.md#10
    hash: a0d6f60a2202e76d2ada9c19476a5b3e8c06ad0e4f4f7ab09df8aa6c461000b4
---

# reviewing-module-design

*Are the boundaries right? Coupling, encapsulation, interfaces that are hard to misuse, illegal states unrepresentable.*

## When to use

Reviews module and type design: cohesion and coupling (via connascence), encapsulation, hard-to-misuse interfaces, and making illegal states unrepresentable. Use when reviewing class/module structure, interfaces, type or data modeling, coupling, or API ergonomics for callers.

**Shape: diff — design-capable.** Also works on design docs and plans: apply the same checks to the proposed states, data flows, and failure paths before any code exists. When the design doc is specifically a decision record (an ADR, RFC, or adoption/deprecation plan), also run the shared **decision-record checklist** on top of this lens's own topical checks: is the rationale actually recorded (not just the outcome); are the stated assumptions still current; is there a revisit-trigger; is an exit, rollback, or sunset path defined; were real alternatives weighed, not just the chosen option justified after the fact? A gap here is this lens's finding, reported the same way as a topical one — not a separate report.

## Reviewer discipline

Report only real problems. If this lens applies and what you reviewed holds up — the code, the design, or the repository's current state — reply "No findings" and stop. If what you were given is outside this lens's scope entirely, say so in one line instead, starting with the words "Not applicable:" followed by what's missing — never the healthy-scan sentence, which means a check ran and found nothing, not that nothing here applied. Either way, do not invent issues. This guards against false positives on correct code; still report every genuine issue you do find, with its full detail.

**Defects are the default; improvements are opt-in.** By default this lens is defect-only: do not suggest changes to code that is already correct. When the team has opted up into improvement suggestions, a finding on already-correct code is admissible only as `nit`-severity, `route: implementer` (the author applies, defers, or ignores), and must clear the non-configurable anti-churn floor: it must genuinely *improve* — never offer a merely equivalent alternative — and must converge (once a dimension is as good as you can confidently make it, stop; never oscillate A→B then B→A, never re-order to an equivalent state). Defects keep the strict bar above regardless of this setting.

**Team preferences.** If the reviewed repo has `.code-quality-atlas/preferences.md`, apply it before reporting: a repo's `.code-quality-atlas/preferences.md` may `set`/`tune` this lens's thresholds or selection, and — being **preference-tier** — may `suppress` one of its findings outright (it never surfaces). Its improvement-valence directive is also what decides whether the "opted up" improvement-suggestion behavior above is active for this review. Absent the file, apply this lens's defaults exactly as written above. Read the overlay from the **base ref** of the change under review — the `/atlas-review-pr` command reads it at the PR's base ref and `/atlas-code-review` reads it from the base side of the diff (`git show <base>:.code-quality-atlas/preferences.md`), and each hands it down — never from the reviewed branch's working tree: an edit to `preferences.md` made *by* the change under review governs later reviews once merged, not the review of the change that makes it, since otherwise a change could `suppress` its own findings.

**Pre-existing defects in touched code are surfaceable, not yours to fix.** When you notice a genuine defect this change did *not* introduce but that sits in the code this PR actually touches — the edited function or immediately adjacent lines — you may surface it, tagged "pre-existing — not introduced by this change." Like improvements it is opt-in and default-quiet (off unless the team opts up), `route: implementer`, and non-blocking: it informs the author's fix-now / file-a-ticket / ignore call and never sets this PR's verdict, because the diff did not cause it. Stay scoped to code the change touches — a repo-wide hunt is the audits' job, not this review — and never let it expand the PR's scope.

## Top checks

The head of the full checklist — enough for a first pass without opening any reference file:

- Is it **hard to misuse** — invalid argument/call-sequence prevented by types, not docs (caller ergonomics / pit of success)?
- **A move changes structure, not just address:** when the diff relocates a file or module (rename-detected, not reviewed as an unrelated add+delete), does the new location actually fit the module boundaries — or does it pull the moved code into a namespace whose other members it has no business depending on, cross a layering rule the rest of the tree observes, or leave a cohesive family split across the old and new locations (half a feature moved, half left behind)? A move that only relocates the file without re-examining whether it now sits with the right neighbors is a missed opportunity to catch a boundary violation while it's cheap to fix (cross #12).
- **Make illegal states unrepresentable — at the earliest, most structural boundary the substrate offers.** The general move behind this whole category: rather than *checking for* a forbidden state correctly on every path, arrange things so the forbidden state **cannot be constructed at all**. The enforcement mechanism is substrate-specific, but the move is one — a **type** in a domain model (a tagged union, a smart constructor); a **schema constraint** in a database (`CHECK`, a scoped `UNIQUE`, a partial index, an exclusion constraint — see the persistence bullets below); a **parsed, typed object** for configuration built once at boot (cross #26); a **validated, discriminated payload** at a wire boundary so an impossible combination can't be expressed (cross #13); a **discriminated union + exhaustiveness check** for UI state (cross #42); a `validation` block or admission schema for infrastructure inputs (cross #31). *Parse, don't validate* is this same move aimed at input — parse untrusted data into a constrained shape **once** at the boundary, rather than validate-then-pass-raw and re-check (or forget to) everywhere downstream. When you see the same guard repeated at call site after call site, ask what one structural change would delete the need for all of them.
- Does the unit have **one** clear responsibility (high cohesion)? State its job in a sentence without "and."
- Is the interface **narrow relative to the behavior** behind it (deep module), or a shallow pass-through adding no value?
- What is the **strongest connascence crossing the boundary**, and is it local? (Position/Algorithm connascence across modules is a smell; prefer Name/Type.)
- Does it **hide its implementation** so internals can change without breaking callers?
- Are **invalid states representable**? Could you construct a value the domain forbids (an order both `draft` and `shipped`)? Model with a tagged union / state machine instead.
- Is untrusted input **parsed into a precise type at the boundary** (parse-don't-validate), or validated then passed onward as raw primitives (re-validatable downstream)?
- **Primitive obsession**: are domain concepts (email, money, id, %) raw `string`/`number`, or wrapped in domain types carrying invariants/units (cross #4)?
- Are optional/nullable fields modeled explicitly (`Option`/`Maybe`/`| null`) rather than sentinel values (`-1`, `""`)?

## Mechanizing these checks

Where a finding here is one a tool can catch deterministically, surface that as an advisory `route: implementer` note next to the finding: the hand review caught it this time, and wiring the matching tool from [reference/tool-rules.md](reference/tool-rules.md) into CI catches it automatically from then on. This is a suggestion to mechanize, not a defect — it never blocks a verdict, and it falls away on a repo that already runs the tool.

**Process notes.** If this lens misfired on this change — flagged correct code, missed an obvious issue squarely in its own scope, or its checklist didn't fit the change shape — say so in one line under `synthesizing-review-findings`'s **Process notes** appendix; that is not a defect finding. Say nothing if the lens worked as intended — never invent a process note to fill the section.

## Going deeper

- [reference/heuristics.md](reference/heuristics.md) — the full checklist; open it when the change sits squarely in this lens's domain.
- [examples.md](examples.md) — concrete good/bad findings, and the output format to match.
- [reference/tool-rules.md](reference/tool-rules.md) — static-analysis rules covering the mechanical subset; for wiring up linters, not needed for the judgment review itself.
- [reference/sources.md](reference/sources.md) — the research behind each check; for provenance, not needed during a review.

<!-- GENERATED by `python -m tooling.cli generate` — do not edit this file directly.
     Canonical sources: docs/research/.
     Direct edits are overwritten on regeneration and fail the CI drift/regenerate gate. -->

<!-- GENERATED — do not hand-edit this file. Vendored by tooling/vendor-skills.sh
     from skills/reviewing-module-design/SKILL.md in code-quality-atlas.
     Edit that file and re-run tooling/vendor-skills.sh to refresh this copy. -->
