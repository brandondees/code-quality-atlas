# Examples — checking-restraint

Report each distinct issue as its own numbered finding. When the input is correct, the entire response is exactly "No findings" — never produce a numbered list of findings for correct code.

## Bad → finding

**Input (diff):**

```python
class NotificationChannelFactory:
    """Pluggable notification backends (currently only email is implemented)."""
    def __init__(self, config: dict):
        self.config = config
        self.plugins = {}

    def register(self, name, channel_cls):
        self.plugins[name] = channel_cls

    def create(self, name="email", **overrides):
        return self.plugins[name](self.config, **overrides)
```

**Expected finding:**

1. **Speculative generality:** a factory + plugin registry + config overrides for a
   single implementation with one caller (YAGNI / rule of three). Inline it to
   `send_email(...)` and extract an abstraction only when a real second channel
   arrives — the right interface is unknowable from one example, and a wrong
   abstraction is costlier than duplication.

## Bad → finding

**Input (diff):**

```js
// Cache user lookups for speed. (Invalidation TODO.)
const userCache = new Map();
function getUser(id) {
  const key = `u:${id}`;
  if (userCache.has(key)) return userCache.get(key);
  const u = db.users.findById(id);   // admin page, ~20 lookups/day
  userCache.set(key, u);
  return u;
}
```

**Expected finding:**

1. **Premature optimization:** a hand-rolled, unbounded cache with no invalidation
   story, on a path measured in calls per day, justified by no profile. Remove the
   cache; if this path ever shows up in a profile, add caching with an explicit
   invalidation/TTL plan then.
2. **Concrete risks the optimization smuggles in:** a stale-user bug (no
   invalidation) and a memory leak (unbounded growth) — when flagging a premature
   optimization, always name the module-level/shared mutable state, staleness, or
   leak it introduces, not just the readability cost.

## Good → no finding

**Input (diff):**

```python
def format_receipt(order):
    lines = [f"{li.name}: {cents_to_display(li.price_cents)}" for li in order.items]
    lines.append(f"Total: {cents_to_display(order.total_cents)}")
    return "\n".join(lines)
```

**Expected finding:** None — a direct, concrete implementation with no speculative
layers. Report "No findings". Do NOT recommend introducing an abstraction, interface,
formatter class, or template engine "for flexibility" — recommending un-needed
abstraction is exactly the failure mode this skill guards against. (When reporting
no findings, say "No findings" plainly; don't borrow a justification from another
case — only cite the rule of three when the repeated call sites are actually named.)

## Good → no finding

**Input (diff):**

```python
# Third call site needing this exact rounding rule (also in billing.py, refunds.py).
def round_to_cents(amount: Decimal) -> Decimal:
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
```

**Expected finding:** None — this extraction is justified by real, repeated need
(rule of three: third occurrence, sites named). Report "No findings"; the rule-of-three
counterweight cuts both ways — do not call a well-evidenced extraction premature.

<!-- GENERATED — do not hand-edit this file. Vendored by tooling/vendor-skills.sh
     from skills/checking-restraint/examples.md in code-quality-atlas.
     Edit that file and re-run tooling/vendor-skills.sh to refresh this copy. -->
